from __future__ import annotations

import json
import hmac
import hashlib
import time
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import urljoin, quote
from typing import Any
from fastapi import HTTPException

import httpx
from fastapi import FastAPI, Depends, Header, HTTPException, Request
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field, HttpUrl
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import (
    Boolean, DateTime, Integer, String, Text, create_engine, select,
    UniqueConstraint
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session




class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    database_url: str = "sqlite:///./consent_poc.db"
    consent_internal_key: str = "CHANGE_ME"
    require_trusted_wso2_headers: bool = True
    gateway_identity_signing_key: str = ""
    gateway_signature_max_age_seconds: int = 60
    wso2_token_url: str = ""
    wso2_client_id: str = ""
    wso2_client_secret: str = ""
    wso2_client_scope: str = ""
    wso2_api_metadata_base: str = ""
    wso2_tls_verify: bool = True
    publisher_roles: str = "consent-publisher,Internal/publisher"
    admin_roles: str = "consent-admin,admin,Internal/admin"
    host: str = "127.0.0.1"
    port: int = 8100


settings = Settings()
connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


def utcnow():
    return datetime.now(timezone.utc)


class ApiOperation(Base):
    __tablename__ = "api_operations"
    __table_args__ = (UniqueConstraint("api_id", "api_version", "operation_id", name="uq_api_version_operation"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    api_id: Mapped[str] = mapped_column(String(255), index=True)
    api_name: Mapped[str] = mapped_column(String(255))
    api_version: Mapped[str] = mapped_column(String(80))
    publisher_subject: Mapped[str] = mapped_column(String(320), index=True)
    operation_id: Mapped[str] = mapped_column(String(255))
    http_method: Mapped[str] = mapped_column(String(10))
    resource_path: Mapped[str] = mapped_column(String(1000))
    upstream_base_url: Mapped[str] = mapped_column(String(2000))
    upstream_path: Mapped[str] = mapped_column(String(1000))
    allowed_fields_json: Mapped[str] = mapped_column(Text, default="[]")
    allowed_purposes_json: Mapped[str] = mapped_column(Text, default='["business"]')
    max_duration_days: Mapped[int] = mapped_column(Integer, default=30)
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ConsentRequest(Base):
    __tablename__ = "consent_requests"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    requester_subject: Mapped[str] = mapped_column(String(320), index=True)
    application_id: Mapped[str] = mapped_column(String(255), index=True)
    api_id: Mapped[str] = mapped_column(String(255), index=True)
    api_version: Mapped[str] = mapped_column(String(80))
    operation_id: Mapped[str] = mapped_column(String(255))
    requested_fields_json: Mapped[str] = mapped_column(Text)
    purpose: Mapped[str] = mapped_column(String(255))
    duration_days: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(40), default="pending")
    decision_by: Mapped[str | None] = mapped_column(String(320), nullable=True)
    decision_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class ConsentGrant(Base):
    __tablename__ = "consent_grants"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    request_id: Mapped[str] = mapped_column(String(36), index=True)
    requester_subject: Mapped[str] = mapped_column(String(320), index=True)
    application_id: Mapped[str] = mapped_column(String(255), index=True)
    api_id: Mapped[str] = mapped_column(String(255), index=True)
    api_version: Mapped[str] = mapped_column(String(80))
    operation_id: Mapped[str] = mapped_column(String(255))
    approved_fields_json: Mapped[str] = mapped_column(Text)
    purpose: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(30), default="active")
    starts_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class AuditEvent(Base):
    __tablename__ = "consent_audit"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor: Mapped[str] = mapped_column(String(320))
    event: Mapped[str] = mapped_column(String(100))
    object_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    details_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


Base.metadata.create_all(engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def internal_auth(x_consent_internal_key: str | None = Header(default=None)):
    expected = settings.consent_internal_key
    if not expected or expected == "CHANGE_ME" or not secrets.compare_digest(x_consent_internal_key or "", expected):
        raise HTTPException(status_code=401, detail="Invalid internal service authentication")


def trusted_identity(
    x_authenticated_user: str | None = Header(default=None),
    x_authenticated_application: str | None = Header(default=None),
    x_authenticated_roles: str | None = Header(default=None),
    x_wso2_api_id: str | None = Header(default=None),
    x_wso2_api_version: str | None = Header(default=None),
    x_wso2_operation_id: str | None = Header(default=None),
    x_consent_timestamp: str | None = Header(default=None),
    x_consent_signature: str | None = Header(default=None),
    request: Request = None,
):
    """No user login/JWT in FastAPI; verify signed identity from trusted adapter.

    An authenticated portal adapter / WSO2 mediator must strip client-provided
    identity/signature headers and sign canonical fields after validating the user.
    Signature is HMAC-SHA256 over timestamp, method, path, user, app, roles,
    API ID, version, operation (one field per line). This is NOT a browser API.
    """
    if not settings.require_trusted_wso2_headers:
        raise HTTPException(503, "Trusted identity enforcement cannot be disabled")
    key = settings.gateway_identity_signing_key
    if not key or len(key) < 32:
        raise HTTPException(503, "GATEWAY_IDENTITY_SIGNING_KEY must be configured (>=32 chars)")
    user = (x_authenticated_user or "").strip()
    application_id = (x_authenticated_application or "").strip()
    roles_raw = (x_authenticated_roles or "").strip()
    api_id = (x_wso2_api_id or "").strip()
    version = (x_wso2_api_version or "").strip()
    operation = (x_wso2_operation_id or "").strip()
    if not user or not application_id or not x_consent_timestamp or not x_consent_signature:
        raise HTTPException(401, "Signed gateway user/application identity is missing")
    try:
        ts = int(x_consent_timestamp)
    except ValueError:
        raise HTTPException(401, "Invalid identity timestamp")
    if abs(int(time.time()) - ts) > settings.gateway_signature_max_age_seconds:
        raise HTTPException(401, "Expired identity signature")
    canonical = "\n".join([str(ts), request.method.upper(), request.url.path,
                            user, application_id, roles_raw, api_id, version, operation])
    expected = hmac.new(key.encode(), canonical.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, x_consent_signature.lower()):
        raise HTTPException(401, "Invalid gateway identity signature")
    return {"user": user, "application_id": application_id,
            "api_id": api_id, "api_version": version, "operation_id": operation,
            "roles": {r.strip() for r in roles_raw.split(",") if r.strip()}}


def require_publisher(ident: dict) -> str:
    allowed_roles = {
        role.strip()
        for role in settings.publisher_roles.split(",")
        if role.strip()
    }
    if not ident.get("roles", set()).intersection(allowed_roles):
        raise HTTPException(403, "Publisher role is required")
    return ident["user"]


def require_admin(ident: dict) -> str:
    allowed_roles = {
        role.strip()
        for role in settings.admin_roles.split(",")
        if role.strip()
    }
    if not ident.get("roles", set()).intersection(allowed_roles):
        raise HTTPException(403, "Admin role is required")
    return ident["user"]

def require_api_owner(db: Session, api_id: str, ident: dict) -> ApiOperation:
    """
    Verify that the authenticated Publisher user owns/manages this API.
    Admins may manage any registered API.
    """
    operations = db.scalars(
        select(ApiOperation).where(ApiOperation.api_id == api_id)
    ).all()

    if not operations:
        raise HTTPException(status_code=404, detail="API not found")

    is_admin = bool(
        ident.get("roles", set()).intersection(
            {r.strip() for r in settings.admin_roles.split(",") if r.strip()}
        )
    )

    owns_api = any(op.publisher_subject == ident["user"] for op in operations)

    if not (is_admin or owns_api):
        raise HTTPException(
            status_code=403,
            detail="You are not authorized to manage consent for this API",
        )

    return operations[0]


def get_operation(
    db: Session,
    api_id: str,
    api_version: str,
    operation_id: str,
) -> ApiOperation:
    op = db.scalar(
        select(ApiOperation).where(
            ApiOperation.api_id == api_id,
            ApiOperation.api_version == api_version,
            ApiOperation.operation_id == operation_id,
            ApiOperation.enabled.is_(True),
        )
    )
    if not op:
        raise HTTPException(
            status_code=404,
            detail="API operation is not registered or enabled for consent",
        )
    return op


def grant_to_dict(g: ConsentGrant) -> dict:
    return {
        "id": g.id,
        "request_id": g.request_id,
        "requester_subject": g.requester_subject,
        "application_id": g.application_id,
        "api_id": g.api_id,
        "api_version": g.api_version,
        "operation_id": g.operation_id,
        "approved_fields": json.loads(g.approved_fields_json),
        "purpose": g.purpose,
        "status": g.status,
        "starts_at": g.starts_at.isoformat() if g.starts_at else None,
        "expires_at": g.expires_at.isoformat() if g.expires_at else None,
        "revoked_at": g.revoked_at.isoformat() if g.revoked_at else None,
    }


def audit(db: Session, actor: str, event: str, object_id: str | None = None, details: dict | None = None):
    db.add(AuditEvent(actor=actor, event=event, object_id=object_id, details_json=json.dumps(details or {})))
    db.commit()


def api_to_dict(op: ApiOperation):
    return {
        "api_id": op.api_id, "api_name": op.api_name, "api_version": op.api_version,
        "publisher_subject": op.publisher_subject, "operation_id": op.operation_id,
        "http_method": op.http_method, "resource_path": op.resource_path,
        "allowed_fields": json.loads(op.allowed_fields_json),
        "allowed_purposes": json.loads(op.allowed_purposes_json),
        "max_duration_days": op.max_duration_days, "enabled": op.enabled,
    }


def request_to_dict(r: ConsentRequest):
    return {
        "id": r.id, "requester_subject": r.requester_subject,
        "application_id": r.application_id, "api_id": r.api_id,
        "api_version": r.api_version, "operation_id": r.operation_id,
        "requested_fields": json.loads(r.requested_fields_json),
        "purpose": r.purpose, "duration_days": r.duration_days, "status": r.status,
        "decision_by": r.decision_by, "decision_note": r.decision_note,
        "created_at": r.created_at.isoformat() if r.created_at else None,
        "decided_at": r.decided_at.isoformat() if r.decided_at else None,
    }


class OperationRegister(BaseModel):
    api_id: str = Field(min_length=1, max_length=255)
    api_name: str = Field(min_length=1, max_length=255)
    api_version: str = Field(min_length=1, max_length=80)
    publisher_subject: str = Field(min_length=1, max_length=320)
    operation_id: str = Field(min_length=1, max_length=255)
    http_method: str = Field(pattern="^(GET|POST|PUT|PATCH|DELETE)$")
    resource_path: str = Field(min_length=1, max_length=1000)
    upstream_base_url: HttpUrl
    upstream_path: str = Field(min_length=1, max_length=1000)
    allowed_fields: list[str] = Field(min_length=1)
    allowed_purposes: list[str] = Field(min_length=1)
    max_duration_days: int = Field(ge=1, le=365)
    enabled: bool = False


class ConsentCreate(BaseModel):
    api_id: str
    api_version: str
    operation_id: str
    application_id: str
    requested_fields: list[str] = Field(min_length=1)
    purpose: str
    duration_days: int = Field(ge=1, le=365)


class Decision(BaseModel):
    decision: str = Field(pattern="^(approve|reject)$")
    approved_fields: list[str] = []
    note: str = ""


app = FastAPI(
    title="Dynamic WSO2 Consent POC",
    version="0.1.0",
    description="One FastAPI application for dynamic API operation registration, consent workflow and JSON response filtering.",
)


@app.get("/health")
def health():
    return {"status": "ok", "service": "dynamic-wso2-consent-poc"}



@app.get("/api/registry")
def list_registry(db: Session = Depends(get_db)):
    operations = db.scalars(
        select(ApiOperation)
        .where(ApiOperation.enabled.is_(True))
        .order_by(
            ApiOperation.api_name,
            ApiOperation.api_version,
        )
    ).all()

    return [api_to_dict(op) for op in operations]



@app.post("/api/registry/operations", dependencies=[Depends(internal_auth)])
def register_operation(payload: OperationRegister, db: Session = Depends(get_db)):
    """Trusted integration/admin endpoint. It is intentionally not open to developers."""
    if not str(payload.upstream_base_url).startswith("https://") and "localhost" not in str(payload.upstream_base_url) and "127.0.0.1" not in str(payload.upstream_base_url):
        raise HTTPException(422, "Upstream must use HTTPS except for local POC backends")
    existing = db.scalar(select(ApiOperation).where(
        ApiOperation.api_id == payload.api_id,
        ApiOperation.api_version == payload.api_version,
        ApiOperation.operation_id == payload.operation_id,
    ))
    data = payload.model_dump()
    data["upstream_base_url"] = str(payload.upstream_base_url).rstrip("/") + "/"
    data["allowed_fields_json"] = json.dumps(payload.allowed_fields)
    data["allowed_purposes_json"] = json.dumps(payload.allowed_purposes)
    data.pop("allowed_fields")
    data.pop("allowed_purposes")
    data.pop("enabled")
    if existing:
        for k, v in data.items():
            setattr(existing, k, v)
        existing.enabled = payload.enabled
        existing.updated_at = utcnow()
        op = existing
    else:
        op = ApiOperation(**data, enabled=payload.enabled)
        db.add(op)
    db.commit()
    db.refresh(op)
    return api_to_dict(op)


@app.post("/api/registry/operations/{op_id}/enable", dependencies=[Depends(internal_auth)])
def enable_operation(op_id: int, db: Session = Depends(get_db)):
    op = db.get(ApiOperation, op_id)
    if not op:
        raise HTTPException(404, "Operation not found")
    op.enabled = True
    db.commit()
    return {"enabled": True, "operation": api_to_dict(op)}


@app.post("/api/consent/requests", status_code=201)
def create_consent_request(
    payload: ConsentCreate,
    ident: dict = Depends(trusted_identity),
    db: Session = Depends(get_db),
):
    import uuid

    # A trusted adapter must provide the actual authenticated application.
    application_id = ident["application_id"]
    requester = ident["user"]

    op = get_operation(
        db, payload.api_id, payload.api_version, payload.operation_id
    )

    allowed_fields = set(json.loads(op.allowed_fields_json))
    requested_fields = set(payload.requested_fields)

    if not requested_fields:
        raise HTTPException(422, "Select at least one field")

    if not requested_fields.issubset(allowed_fields):
        raise HTTPException(
            422, "Requested fields exceed the registered API policy"
        )

    allowed_purposes = set(json.loads(op.allowed_purposes_json))
    if payload.purpose not in allowed_purposes:
        raise HTTPException(422, "Purpose is not permitted for this API operation")

    if payload.duration_days > op.max_duration_days:
        raise HTTPException(
            422, f"Maximum consent duration is {op.max_duration_days} days"
        )

    row = ConsentRequest(
        id=str(uuid.uuid4()),
        requester_subject=requester,
        application_id=application_id,
        api_id=op.api_id,
        api_version=op.api_version,
        operation_id=op.operation_id,
        requested_fields_json=json.dumps(sorted(requested_fields)),
        purpose=payload.purpose,
        duration_days=payload.duration_days,
        status="pending",
    )

    db.add(row)
    db.commit()
    db.refresh(row)

    audit(
        db, requester, "consent.request.created", row.id,
        {
            "application_id": application_id,
            "api_id": op.api_id,
            "api_version": op.api_version,
            "operation_id": op.operation_id,
        },
    )

    return request_to_dict(row)


@app.get("/api/consent/requests/mine")
def my_requests(
    ident: dict = Depends(trusted_identity),
    db: Session = Depends(get_db),
):
    rows = db.scalars(
        select(ConsentRequest)
        .where(
            ConsentRequest.requester_subject == ident["user"],
            ConsentRequest.application_id == ident["application_id"],
        )
        .order_by(ConsentRequest.created_at.desc())
    ).all()

    return [request_to_dict(row) for row in rows]


@app.get("/api/consent/requests/pending")
def pending_requests(
    ident: dict = Depends(trusted_identity),
    db: Session = Depends(get_db),
):
    require_publisher(ident)

    # Only return requests for APIs this Publisher owns, unless admin.
    all_pending = db.scalars(
        select(ConsentRequest)
        .where(ConsentRequest.status == "pending")
        .order_by(ConsentRequest.created_at.asc())
    ).all()

    is_admin = bool(
        ident["roles"].intersection(
            {r.strip() for r in settings.admin_roles.split(",") if r.strip()}
        )
    )

    result = []
    for row in all_pending:
        operations = db.scalars(
            select(ApiOperation).where(
                ApiOperation.api_id == row.api_id,
                ApiOperation.api_version == row.api_version,
                ApiOperation.operation_id == row.operation_id,
            )
        ).all()

        if is_admin or any(
            op.publisher_subject == ident["user"] for op in operations
        ):
            result.append(request_to_dict(row))

    return result


@app.post("/api/consent/requests/{request_id}/decision")
def decide_request(
    request_id: str,
    payload: Decision,
    ident: dict = Depends(trusted_identity),
    db: Session = Depends(get_db),
):
    import uuid

    publisher = require_publisher(ident)

    row = db.get(ConsentRequest, request_id)
    if not row:
        raise HTTPException(404, "Consent request not found")

    if row.status != "pending":
        raise HTTPException(409, "This request has already been decided")

    require_api_owner(db, row.api_id, ident)

    op = get_operation(
        db, row.api_id, row.api_version, row.operation_id
    )

    now = utcnow()

    if payload.decision == "reject":
        row.status = "rejected"
        row.decision_by = publisher
        row.decision_note = payload.note
        row.decided_at = now
        db.commit()
        db.refresh(row)

        audit(db, publisher, "consent.request.rejected", row.id)
        return request_to_dict(row)

    requested = set(json.loads(row.requested_fields_json))
    policy_fields = set(json.loads(op.allowed_fields_json))
    approved = set(payload.approved_fields)

    if not approved:
        raise HTTPException(422, "Select at least one field to approve")

    if not approved.issubset(requested):
        raise HTTPException(
            422, "Approved fields must be a subset of the requested fields"
        )

    if not approved.issubset(policy_fields):
        raise HTTPException(
            422, "Approved fields violate the registered API policy"
        )

    grant = ConsentGrant(
        id=str(uuid.uuid4()),
        request_id=row.id,
        requester_subject=row.requester_subject,
        application_id=row.application_id,
        api_id=row.api_id,
        api_version=row.api_version,
        operation_id=row.operation_id,
        approved_fields_json=json.dumps(sorted(approved)),
        purpose=row.purpose,
        status="active",
        starts_at=now,
        expires_at=now + timedelta(days=row.duration_days),
    )

    db.add(grant)

    row.status = (
        "approved" if approved == requested else "partially_approved"
    )
    row.decision_by = publisher
    row.decision_note = payload.note
    row.decided_at = now

    db.commit()
    db.refresh(row)
    db.refresh(grant)

    audit(
        db, publisher, "consent.grant.created", grant.id,
        {
            "request_id": row.id,
            "application_id": row.application_id,
            "approved_fields": sorted(approved),
        },
    )

    return {
        "request": request_to_dict(row),
        "grant": grant_to_dict(grant),
    }


@app.get("/api/consent/requests/pending")
def pending_requests(db: Session = Depends(get_db)):
    """Public demo view: pending requests for all registered APIs."""
    rows = db.scalars(
        select(ConsentRequest)
        .where(
            ConsentRequest.requester_subject == "public-demo",
            ConsentRequest.status == "pending",
        )
        .order_by(ConsentRequest.created_at)
    ).all()
    return [request_to_dict(row) for row in rows]


@app.post("/api/consent/requests/{request_id}/decision")
def decide_request(
    request_id: str,
    payload: Decision,
    db: Session = Depends(get_db),
):
    """Public demo approval endpoint. Anyone who can reach it can decide requests."""
    import uuid

    publisher = "public-demo-publisher"
    request_row = db.get(ConsentRequest, request_id)
    if not request_row:
        raise HTTPException(404, "Consent request not found")
    if request_row.status != "pending":
        raise HTTPException(409, "This request has already been decided")

    op = db.scalar(select(ApiOperation).where(
        ApiOperation.api_id == request_row.api_id,
        ApiOperation.api_version == request_row.api_version,
        ApiOperation.operation_id == request_row.operation_id,
    ))
    if not op:
        raise HTTPException(404, "API operation policy was not found")

    now = utcnow()
    if payload.decision == "reject":
        request_row.status = "rejected"
        request_row.decision_by = publisher
        request_row.decision_note = payload.note
        request_row.decided_at = now
        db.commit()
        audit(db, publisher, "consent.request.rejected", request_row.id, {"note": payload.note})
        return request_to_dict(request_row)

    requested = set(json.loads(request_row.requested_fields_json))
    policy_allowed = set(json.loads(op.allowed_fields_json))
    approved = set(payload.approved_fields)
    if not approved:
        raise HTTPException(422, "Select at least one field to approve")
    if not approved.issubset(requested):
        raise HTTPException(422, "Approved fields must be a subset of requested fields")
    if not approved.issubset(policy_allowed):
        raise HTTPException(422, "Approved fields violate the API policy")

    grant = ConsentGrant(
        id=str(uuid.uuid4()), request_id=request_row.id,
        requester_subject=request_row.requester_subject,
        application_id=request_row.application_id,
        api_id=request_row.api_id, api_version=request_row.api_version,
        operation_id=request_row.operation_id,
        approved_fields_json=json.dumps(sorted(approved)),
        purpose=request_row.purpose, status="active", starts_at=now,
        expires_at=now + timedelta(days=request_row.duration_days),
    )
    db.add(grant)
    request_row.status = "approved" if approved == requested else "partially_approved"
    request_row.decision_by = publisher
    request_row.decision_note = payload.note
    request_row.decided_at = now
    db.commit()
    db.refresh(request_row)
    db.refresh(grant)
    audit(db, publisher, "consent.grant.created", grant.id, {
        "request_id": request_row.id, "fields": sorted(approved)
    })
    return {
        "request": request_to_dict(request_row),
        "grant": {
            "id": grant.id,
            "approved_fields": sorted(approved),
            "expires_at": grant.expires_at.isoformat(),
        },
    }


@app.get("/api/consent/grants/mine")
def my_grants(
    ident: dict = Depends(trusted_identity),
    db: Session = Depends(get_db),
):
    rows = db.scalars(
        select(ConsentGrant)
        .where(
            ConsentGrant.requester_subject == ident["user"],
            ConsentGrant.application_id == ident["application_id"],
        )
        .order_by(ConsentGrant.expires_at.desc())
    ).all()

    return [grant_to_dict(row) for row in rows]


@app.post("/api/consent/grants/{grant_id}/revoke")
def revoke_grant(
    grant_id: str,
    ident: dict = Depends(trusted_identity),
    db: Session = Depends(get_db),
):
    grant = db.get(ConsentGrant, grant_id)
    if not grant:
        raise HTTPException(404, "Grant not found")

    # The requester may revoke their own grant; a Publisher or admin may
    # revoke it only if authorized to manage the associated API.
    is_requester = (
        grant.requester_subject == ident["user"]
        and grant.application_id == ident["application_id"]
    )

    if not is_requester:
        require_publisher(ident)
        require_api_owner(db, grant.api_id, ident)

    if grant.status != "revoked":
        grant.status = "revoked"
        grant.revoked_at = utcnow()
        db.commit()

        audit(db, ident["user"], "consent.grant.revoked", grant.id)

    return {"status": "revoked", "grant_id": grant.id}


@app.post("/api/consent/grants/{grant_id}/revoke")
def revoke_grant(grant_id: str, db: Session = Depends(get_db)):
    """Public demo revoke endpoint. Anyone can revoke a grant in public mode."""
    grant = db.get(ConsentGrant, grant_id)
    if not grant:
        raise HTTPException(404, "Grant not found")
    grant.status = "revoked"
    grant.revoked_at = utcnow()
    db.commit()
    audit(db, "public-demo", "consent.grant.revoked", grant.id)
    return {"status": "revoked", "grant_id": grant.id}


def filter_json(value: Any, approved_fields: set[str]) -> Any:
    """
    Keep only approved keys in JSON objects.
    Applies recursively to nested objects and arrays.

    This is a key-name filter, not a substitute for schema-aware
    filtering where identical field names have different meanings.
    """
    if isinstance(value, dict):
        return {
            key: filter_json(item, approved_fields)
            for key, item in value.items()
            if key in approved_fields
        }

    if isinstance(value, list):
        return [
            filter_json(item, approved_fields)
            for item in value
        ]

    return value


@app.api_route(
    "/proxy/{api_id}/{api_version}/{operation_id}",
    methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
)
async def proxy_api(
    api_id: str,
    api_version: str,
    operation_id: str,
    request: Request,
    ident: dict = Depends(trusted_identity),
    db: Session = Depends(get_db),
):
    method = request.method.upper()

    # Require signed identity context to match the requested operation.
    # The trusted adapter must derive these values from the actual WSO2
    # route/API context, not from arbitrary client headers.
    if (
        ident["api_id"] != api_id
        or ident["api_version"] != api_version
        or ident["operation_id"] != operation_id
    ):
        raise HTTPException(403, "Signed API context does not match this request")

    op = db.scalar(
        select(ApiOperation).where(
            ApiOperation.api_id == api_id,
            ApiOperation.api_version == api_version,
            ApiOperation.operation_id == operation_id,
            ApiOperation.http_method == method,
            ApiOperation.enabled.is_(True),
        )
    )
    if not op:
        raise HTTPException(404, "API operation is not registered or enabled")

    purpose = (request.headers.get("X-Consent-Purpose") or "").strip()
    if not purpose:
        raise HTTPException(400, "X-Consent-Purpose is required")

    allowed_purposes = set(json.loads(op.allowed_purposes_json))
    if purpose not in allowed_purposes:
        raise HTTPException(403, "Purpose is not permitted by API policy")

    now = utcnow()

    # Critical: application_id is now part of the grant lookup.
    grants = db.scalars(
        select(ConsentGrant).where(
            ConsentGrant.requester_subject == ident["user"],
            ConsentGrant.application_id == ident["application_id"],
            ConsentGrant.api_id == api_id,
            ConsentGrant.api_version == api_version,
            ConsentGrant.operation_id == operation_id,
            ConsentGrant.purpose == purpose,
            ConsentGrant.status == "active",
            ConsentGrant.starts_at <= now,
            ConsentGrant.expires_at > now,
            ConsentGrant.revoked_at.is_(None),
        )
    ).all()

    if not grants:
        raise HTTPException(
            403, "No active consent grant matches this application and operation"
        )

    if len(grants) != 1:
        raise HTTPException(
            409, "Multiple active grants match; resolve duplicate consent grants"
        )

    approved_fields = set(json.loads(grants[0].approved_fields_json))

    upstream = (
        str(op.upstream_base_url).rstrip("/")
        + "/"
        + op.upstream_path.lstrip("/")
    )

    # Forward only necessary request headers. Never forward the client's
    # consent identity/signature headers to the upstream backend.
    forward_headers = {}
    content_type = request.headers.get("content-type")
    if content_type:
        forward_headers["content-type"] = content_type

    body = await request.body()
    params = list(request.query_params.multi_items())

    try:
        async with httpx.AsyncClient(
            verify=settings.wso2_tls_verify,
            timeout=20.0,
            follow_redirects=False,
        ) as client:
            upstream_response = await client.request(
                method=method,
                url=upstream,
                params=params,
                content=body or None,
                headers=forward_headers,
            )
    except httpx.HTTPError:
        raise HTTPException(502, "Configured upstream API is unavailable")

    content_type = upstream_response.headers.get("content-type", "")

    # This implementation intentionally rejects unsupported response types.
    # Add separate enforcement for binary, streaming, SOAP or other formats
    # instead of accidentally returning unfiltered data.
    if "application/json" not in content_type.lower():
        raise HTTPException(
            502, "Consent filtering is configured for JSON responses only"
        )

    try:
        upstream_payload = upstream_response.json()
    except ValueError:
        raise HTTPException(502, "Upstream returned invalid JSON")

    filtered_payload = filter_json(upstream_payload, approved_fields)

    return JSONResponse(
        content=filtered_payload,
        status_code=upstream_response.status_code,
    )

@app.get("/api/wso2/metadata-health", dependencies=[Depends(internal_auth)])
async def metadata_health():
    configured = bool(settings.wso2_token_url and settings.wso2_client_id and settings.wso2_client_secret and settings.wso2_api_metadata_base)
    return {
        "configured": configured,
        "message": "Automatic WSO2 API metadata sync and per-business-API subscription verification are not yet implemented; register metadata through a trusted adapter and add subscription verification before production.",
        "metadata_base_configured": bool(settings.wso2_api_metadata_base),
    }