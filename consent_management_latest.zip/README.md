# Dynamic WSO2 Consent - FastAPI service

This folder contains the FastAPI backend from the supplied `wso2-dynamic-consent-poc-full-guide` ZIP.

## What it includes

- Dynamic API operation registry keyed by API ID, version, and operation ID
- Consent request creation and request history
- Publisher pending-request list and approve/reject decision endpoints
- Consent grants and API proxy/response filtering endpoints (see `app/main.py`)
- SQLAlchemy persistence; SQLite for local POC or PostgreSQL for shared testing
- Internal service-key authentication for registry and publisher integration endpoints
- OpenAPI/Swagger UI at `/docs` when the service is running

## 1. Create and activate a virtual environment

Linux/macOS:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows PowerShell:
```powershell
py -m venv .venv
.venv\\Scripts\\Activate.ps1
```

## 2. Install dependencies

```bash
pip install -r requirements.txt
```

## 3. Configure environment

Copy `.env.example` to `.env`. For a local-only test, SQLite is configured by default. Replace `CONSENT_INTERNAL_KEY` with a long random secret before using any protected integration endpoints.

Keep `HOST=127.0.0.1` for local-only access. Do not expose this service directly to the public Internet.

For PostgreSQL, change `DATABASE_URL` to a SQLAlchemy psycopg URL, for example:
`postgresql+psycopg://consent_user:YOUR_PASSWORD@127.0.0.1:5432/consent_db`

## 4. Start the service

```bash
uvicorn app.main:app --host 127.0.0.1 --port 8100 --reload
```

Open:
- Health: http://127.0.0.1:8100/health
- Swagger UI: http://127.0.0.1:8100/docs
- OpenAPI JSON: http://127.0.0.1:8100/openapi.json

## Important integration notes

1. This is the FastAPI code included in the source ZIP, packaged separately for convenience; it is not a newly verified production implementation.
2. WSO2 must inject trusted user/application/API/operation identity only after authenticating the caller and removing client-supplied spoofable identity headers.
3. The publisher UI must not be allowed to choose an arbitrary `publisher_subject`. Enforce the current Publisher identity server-side and validate API ownership.
4. The example UI may use a different API prefix. Align its `apiBase` with the actual deployed route/base path.
5. The service's internal key is for trusted integration only. Never put it in browser code.
6. Database tables are created by SQLAlchemy at startup/import via `Base.metadata.create_all(engine)` in this POC. Use proper migrations before production.
7. Developer OAuth credentials/subscriptions remain managed by WSO2; this service does not replace WSO2 gateway authentication.

See `WSO2-INTEGRATION-NOTES.md` and `TEST-FLOW.md` before connecting it to WSO2.
